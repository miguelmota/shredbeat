# shredbeat

> Music beat reacts to your keyboard shredding speed

<img src="https://github.com/miguelmota/shredbeat/blob/master/screenshot.png?raw=true" width="400">

NOTE: this is a dirty MVP. Currenly only works in Mac OS X, and only supports SoundCloud.

## Development

install

```bash
npm install
```

start

```bash
npm run start
```

start in development mode

```bash
npm run start:dev
```

watch and build browser files

```bash
npm run watch
```

## Resources

- [electron](http://electron.atom.io)
